export type BookingUser = {
  id?: number;
  userName?: string;
  firstName?: string;
  secondName?: string;
  userRole?: string;
  pin?: number;
  email?: string;
  telephoneNumber?: string;
  authtoken?: string;
};
