package pk.service;

public class InvalidPasswordException extends  RuntimeException{
    
}
