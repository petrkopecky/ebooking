package pk.service;

public interface BookingTableStructureService {
    public String getBookingTableStructure();
}
