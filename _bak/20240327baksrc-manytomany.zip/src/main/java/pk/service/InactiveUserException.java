package pk.service;

public class InactiveUserException extends  RuntimeException{
    
}
