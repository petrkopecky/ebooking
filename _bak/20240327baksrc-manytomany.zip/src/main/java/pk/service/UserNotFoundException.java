package pk.service;

public class UserNotFoundException extends  RuntimeException{

}
