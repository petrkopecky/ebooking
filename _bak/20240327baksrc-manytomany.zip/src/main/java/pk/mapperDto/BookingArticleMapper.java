package pk.mapperDto;

import org.mapstruct.Mapper;
import pk.entity.BookingArticle;
import pk.modelDto.BookingArticleDto;

import java.util.List;

//@Mapper
public interface BookingArticleMapper {
  /*  BookingArticleDto bookingArticleToBookingArticleDto(BookingArticle bookingArticle);
    BookingArticle bookingArticleDtoToBookingArticle( BookingArticleDto bookingArticleDto);


    List<BookingArticleDto> bookingArticlesToBookingArticlesDto(List<BookingArticle> bookingArticles);
    List<BookingArticle> bookingArticlesDtoToBookingArticles( List<BookingArticleDto> bookingArticlesDto);
*/
}

